package com.cts.resource;

import org.hibernate.SessionFactory;
import org.hibernate.cfg.AnnotationConfiguration;

public class HibernateUtil 
{
	private static final SessionFactory sf;
	static
	{
		try
		{
			sf=new AnnotationConfiguration().configure("com/cts/resource/hibernate.cfg.xml").buildSessionFactory();
		}
		catch(Throwable ex)
		{
			System.err.println("initial sessionfactory creation failed."+ex);
			throw new ExceptionInInitializerError(ex);
		}
		
		
	}

    public static SessionFactory getSessionFactory() {
        return sf;
    }

}
