package com.cts.service;

import java.util.List;

import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.GenericEntity;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;






import com.cts.dao.LocationDAO;
import com.cts.entity.Location;

@Path("/LocationService")
public class LocationService 
{
	@Path("/AddLocation")
	@POST
	@Consumes({MediaType.APPLICATION_JSON,MediaType.APPLICATION_XML})
	@Produces({MediaType.APPLICATION_JSON,MediaType.APPLICATION_XML})
	public Response AddLocation(Location location)
	{
		
		LocationDAO.insertLocation(location);			
				
			return Response.status(200)
					.header("Access-Control-Allow-Origin", "*")
					.header("Access-Control-Allow-Headers", "origin, content-type, accept, authorization")
					.header("Access-Control-Allow-Credentials","true")
					.header("Access-Control-Allow-Methods", "GET, POST, PUT, DELETE, OPTIONS, HEAD")
					.header("Access-Control-Max-Age",100052)
					.entity(location).build();	
		
	}
	@Path("/Getlocations")
	@GET
	@Produces({MediaType.APPLICATION_JSON,MediaType.APPLICATION_XML})
	public static Response GetLocation()
	{
		String message=LocationDAO.getALL().size()+"recivied";
		GenericEntity<List<Location>> generic=new GenericEntity<List<Location>>(LocationDAO.getALL()){};
	
		System.out.println("done");
		return Response.status(200)
				.header("Access-Control-Allow-Origin", "*")
				.header("Access-Control-Allow-Headers", "origin, content-type, accept, authorization")
				.header("Access-Control-Allow-Credentials","true")
				.header("Access-Control-Allow-Methods", "GET, POST, PUT, DELETE, OPTIONS, HEAD")
				.header("Access-Control-Max-Age",100052)
				.entity(generic).build();	

		
		
		
		
		
	}


}
