package com.cts.service;

import java.util.List;

import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.GenericEntity;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import com.cts.dao.EventDao;
import com.cts.dao.LocationDAO;
import com.cts.entity.Event;
import com.cts.entity.Location;

@Path("/EventService")
public class EventService 
{
	@POST
	@Path("/AddEvent")
	@Consumes({MediaType.APPLICATION_JSON,MediaType.APPLICATION_XML})
	@Produces({MediaType.APPLICATION_JSON,MediaType.APPLICATION_XML})
	public Response AddEvent(Event event)
	{
		
		EventDao.AddEvent(event);
		
		
		return Response.status(200)
				.header("Access-Control-Allow-Origin", "*")
				.header("Access-Control-Allow-Headers", "origin, content-type, accept, authorization")
				.header("Access-Control-Allow-Credentials","true")
				.header("Access-Control-Allow-Methods", "GET, POST, PUT, DELETE, OPTIONS, HEAD")
				.header("Access-Control-Max-Age",100052)
				.entity(event).build();
		
	}
	
	@Path("/GetEvents")
	@GET
	@Produces({MediaType.APPLICATION_JSON,MediaType.APPLICATION_XML})
	public static Response GetLocation()
	{
		String message=EventDao.getALL().size()+"recivied";
		GenericEntity<List<Event>> generic=new GenericEntity<List<Event>>(EventDao.getALL()){};
	
		System.out.println("done");
		return Response.status(200)
				.header("Access-Control-Allow-Origin", "*")
				.header("Access-Control-Allow-Headers", "origin, content-type, accept, authorization")
				.header("Access-Control-Allow-Credentials","true")
				.header("Access-Control-Allow-Methods", "GET, POST, PUT, DELETE, OPTIONS, HEAD")
				.header("Access-Control-Max-Age",100052)
				.entity(generic).build();	

		
		
		
		
		
	}
	

}
