package com.cts.dao;




import java.util.List;

import org.eclipse.jdt.internal.compiler.apt.model.Factory;
import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;

import com.cts.entity.Location;
import com.cts.resource.HibernateUtil;

public class LocationDAO 
{
	private static SessionFactory factory;
	private static Session s;
	
	public static void insertLocation(Location location)
	{
		SessionFactory factory=HibernateUtil.getSessionFactory();
		Session s=factory.openSession();
		try
		{
			Transaction trans=s.beginTransaction();
			s.save(location);
			trans.commit();
			
		}
		catch(HibernateException he)
		{
			he.printStackTrace();
			
		}
		finally{
			if(s!=null){
				s.close();
			}
	
		System.out.println("Location inserted into location master");
	}

	}
	
	public static List<Location> getALL()
	{
		System.out.println("all locations");
		factory=HibernateUtil.getSessionFactory();
		s=factory.openSession();
		List<Location> location=s.createQuery("from Location").list();
		return location;
	}
	
	
	
}
