package com.cts.dao;

import java.util.List;

import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;

import com.cts.entity.Event;
import com.cts.resource.HibernateUtil;

public class EventDao 
{
	private static SessionFactory factory;
	private static Session session;
	public static void AddEvent(Event event)
	{
		factory=HibernateUtil.getSessionFactory();
		session=factory.openSession();
		
		try {
			Transaction trans=session.beginTransaction();
			session.save(event);
			trans.commit();
		} catch (HibernateException he) {
			// TODO Auto-generated catch block
			he.printStackTrace();
			System.out.println(" add event is not working properly");
		}
		
		finally
		{
		if(session!=null)
		{
			session.close();
		}
		}
		System.out.println("Event inserted into event master");
	}
	
	public static List<Event> getALL()
	{
		System.out.println("all locations");
		factory=HibernateUtil.getSessionFactory();
		session=factory.openSession();
		List<Event> event=session.createQuery("from Event").list();
		return event;
	}
	
	

}
