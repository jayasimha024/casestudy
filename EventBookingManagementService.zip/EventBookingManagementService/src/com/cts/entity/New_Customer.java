package com.cts.entity;

public class New_Customer extends Customer
{
	

}
