package com.cts.entity;

import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement
public class Message 
{

	private String Status;

	public String getStatus() {
		return Status;
	}

	public void setStatus(String status) {
		Status = status;
	}
	
	
	
	
}
