package com.cts.entity;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.xml.bind.annotation.XmlRootElement;

@Entity
@Table(name="Event")
@XmlRootElement
public class Event 
{
	@Id
	@Column(name="eventid")
	private int eventid;
	@Column(name="evnetname")
	private String eventName;
	
	@Temporal(TemporalType.DATE)
	@Column(name="eventDate")
	private Date eventDate;
	@Column(name="tickets")
	private boolean tickets_avl;
	
	@OneToOne
	@JoinColumn(name="locationid")
	private Location location;
	
	
	
	
	public int getEventid() {
		return eventid;
	}
	public void setEventid(int eventid) {
		this.eventid = eventid;
	}
	public String getEventName() {
		return eventName;
	}
	public void setEventName(String eventName) {
		this.eventName = eventName;
	}
	public Date getEventDate() {
		return eventDate;
	}
	public void setEventDate(Date eventDate) {
		this.eventDate = eventDate;
	}
	public boolean isTickets_avl() {
		return tickets_avl;
	}
	public void setTickets_avl(boolean tickets_avl) {
		this.tickets_avl = tickets_avl;
	}
	public Location getLocation() {
		return location;
	}
	public void setLocation(Location location) {
		this.location = location;
	}
	
	
	
	
	

}
