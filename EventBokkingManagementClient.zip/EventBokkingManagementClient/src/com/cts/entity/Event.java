package com.cts.entity;

import java.util.Date;




public class Event 
{
	private int eventid;
	private String eventName;
	private Date eventDate;
	private boolean tickets_avl;
	private Location location;
	public int getEventid() {
		return eventid;
	}
	public void setEventid(int eventid) {
		this.eventid = eventid;
	}
	public String getEventName() {
		return eventName;
	}
	public void setEventName(String eventName) {
		this.eventName = eventName;
	}
	public Date getEventDate() {
		return eventDate;
	}
	public void setEventDate(Date eventDate) {
		this.eventDate = eventDate;
	}
	public boolean isTickets_avl() {
		return tickets_avl;
	}
	public void setTickets_avl(boolean tickets_avl) {
		this.tickets_avl = tickets_avl;
	}
	public Location getLocation() {
		return location;
	}
	public void setLocation(Location location) {
		this.location = location;
	}
	
	
	

}
