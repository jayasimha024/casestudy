package com.cts.entity;

import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement
public class Location 
{
	private int locationid;
	private String locationName;
	
	
	public int getLocationid() {
		return locationid;
	}
	public void setLocationid(int locationid) {
		this.locationid = locationid;
	}
	public String getLocationName() {
		return locationName;
	}
	public void setLocationName(String locationName) {
		this.locationName = locationName;
	}
	
	
	

}
