package com.cts.services;

import java.util.List;
import java.util.Properties;

import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.QueryParam;
import javax.ws.rs.core.Response;

import com.cts.entities.Employee;
@Path("/EmployeeService")
public class EmployeeService {
	//EmployeeService/getemployeedetails?employeeid=2&name=sowjanya&skillset=java&skillset=.net
	@GET
	@Path("/getemployeedetails")
public Response  employeedetails(@QueryParam("employeeid")int employeeid,@QueryParam("name")String name,@QueryParam("skillset")List<String> skillset)
{
	Employee emp=new Employee();
	emp.setEmployeeid(employeeid);
	emp.setName(name);
	emp.setSkillset(skillset);
	return Response
			 .status(200)
           .header("Access-Control-Allow-Origin", "*")
	            .header("Access-Control-Allow-Headers", "origin, content-type, accept, authorization")
	            .header("Access-Control-Allow-Credentials", "true")
	            .header("Access-Control-Allow-Methods", "GET, POST, PUT, DELETE, OPTIONS, HEAD")
	            .header("Access-Control-Max-Age", "1209600")
	            .entity(emp)
	            .build();
}
}
