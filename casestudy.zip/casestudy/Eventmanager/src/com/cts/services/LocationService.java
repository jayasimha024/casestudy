package com.cts.services;

import javax.ws.rs.Consumes;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import com.cts.dao.Customermanager;
import com.cts.dao.Locationmanager;
import com.cts.entities.Customer;
import com.cts.entities.Location;
import com.cts.entities.Message;
@Path("/locationservices")
public class LocationService {
	@POST
	@Produces({MediaType.APPLICATION_JSON,MediaType.APPLICATION_XML})
	@Consumes({MediaType.APPLICATION_JSON,MediaType.APPLICATION_XML})
	@Path("/addlocation")
		public Response AddLocationService(Location location){
			
	boolean	status=Locationmanager.AddLocation(location);
	Message message=new Message();
	message.setStatus("not insert");
	if(status)
	{
		message.setStatus("record added");
	}

		return Response
								 .status(200)
					            .header("Access-Control-Allow-Origin", "*")
						            .header("Access-Control-Allow-Headers", "origin, content-type, accept, authorization")
						            .header("Access-Control-Allow-Credentials", "true")
						            .header("Access-Control-Allow-Methods", "GET, POST, PUT, DELETE, OPTIONS, HEAD")
						            .header("Access-Control-Max-Age", "1209600")
						            .entity(message)
						            .build();
	}
}
